// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/model/admin');
import ExportDetails = require('../../../app/model/details');
import ExportStaff = require('../../../app/model/staff');
import ExportStudnet = require('../../../app/model/studnet');

declare module 'egg' {
  interface IModel {
    Admin: ReturnType<typeof ExportAdmin>;
    Details: ReturnType<typeof ExportDetails>;
    Staff: ReturnType<typeof ExportStaff>;
    Studnet: ReturnType<typeof ExportStudnet>;
  }
}
