// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/controller/admin');
import ExportHome = require('../../../app/controller/home');
import ExportStaff = require('../../../app/controller/staff');
import ExportStudent = require('../../../app/controller/student');
import ExportZhuce = require('../../../app/controller/zhuce');

declare module 'egg' {
  interface IController {
    admin: ExportAdmin;
    home: ExportHome;
    staff: ExportStaff;
    student: ExportStudent;
    zhuce: ExportZhuce;
  }
}
