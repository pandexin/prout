// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/service/admin');
import ExportDetails = require('../../../app/service/details');
import ExportStaff = require('../../../app/service/staff');
import ExportStudent = require('../../../app/service/student');

declare module 'egg' {
  interface IService {
    admin: ExportAdmin;
    details: ExportDetails;
    staff: ExportStaff;
    student: ExportStudent;
  }
}
