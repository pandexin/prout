'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  // router.get('/', controller.home.index);
  router.get('/',controller.zhuce.zhuce)
  router.post('/insertadmin',controller.zhuce.insertadmin)
  router.post('/registereds',controller.zhuce.create)

};
