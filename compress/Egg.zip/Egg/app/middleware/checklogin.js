module.exports = () => {
    return async function (ctx, next) {
        if (ctx.session.zhuce) {
            await next();
        } else {
            await ctx.redirect("/insertadmin")
        }
    }
}
