'use strict';

const Service = require('egg').Service;

class StudentService extends Service {
    async get() {
        const studentlist = await this.app.model.Student.findAll();
        return studentlist
    }
    async delect() {
        let id = this.ctx.params.id
        const student = await this.app.model.Student.findOne({
            where: {
                id: id
            }
        })
        student.destroy()
    }
    async poststudent() {
        const body = this.ctx.request.body;
        const student = {
            student_name: body.name,
            student_school: body.school,
            student_phone: body.phone,
            student_categorys: body.categorys,
            parent_name: body.name,
            parent_phone: body.phone,
        }
        await this.app.model.Student.post(student);
        // this.ctx.redirect("/student")
    }
    async putstudent() {
        let id = this.ctx.params.id
        let putstudentname = this.ctx.request.body.putstudentname
        let row = {
            name: putstudentname
        },
            options = {
                where: {
                    id: id
                }
            }
        await this.app.model.Student.update(row, options);
        const studentList = await this.app.model.Student.findAll();
        return studentList
    }
}

module.exports = StudentService;
// http://127.0.0.1:7001/studentF