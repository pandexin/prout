'use strict';

const Service = require('egg').Service;

class AdminService extends Service {
    async getadmin() {
        const getadmin = await this.app.model.Admin.findAll();
        return getadmin
      }
    async insertadmin() {
        let username = this.ctx.request.body.username;
        console.log(username)
        let password = this.ctx.request.body.password;
        console.log(password)
        let admin = await this.app.model.Admin.findOne({
            where:{
                username:username,
            }
        });
        console.log(1111111111111111111111111111)
        console.log(1111111111111111111111111111)
        if(admin == null){
            this.ctx.body = "用户不存在";
            return
        }else{
            
        }
        //判断密码是否想·正确，正确则登录成功
        if(password == admin.password){
            // this.ctx.session.user = user;  //设置session
            this.ctx.body='登录成功'
            
            // console.log("sssssssss")
        }else{
            // console.log("zzzzzzzzz")
            this.ctx.body = "密码错误！"
        }
    }
}

module.exports = AdminService;
// http://127.0.0.1:7001/admin/insertadmin
// http://127.0.0.1:7001/insertadmin