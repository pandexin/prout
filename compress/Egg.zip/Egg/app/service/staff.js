'use strict';

const Service = require('egg').Service;

class StaffService extends Service {
   async getstaff() {
    const getstafflist = await this.app.model.Staff.findAll();
    return getstafflist
  }
  async delectstaff() {
    let id = this.ctx.params.id
    const staff = await this.app.model.Staff.findOne({
      where: {
        id: id
      }
    })
    staff.destroy()
  }
  async poststaff() {
    const body = this.ctx.request.body;
    const staff = {
      staff_name: body.name,
      staff_school: body.school,
      staff_phone: body.phone,
    }
    await this.app.model.Staff.post(staff);
    // this.ctx.redirect("/student")
  }
  async putstaff() {
    let id = this.ctx.params.id
    let putstaffname = this.ctx.request.body.putstaffname
    let row = {
      name: putstaffname
    }, 
      options = {
        where: {
          id: id
        }
      }
    await this.app.model.Staff.update(row, options);
    const staffList = await this.app.model.Staff.findAll();
    return staffList
  }
}
    
module.exports = StaffService;
// http://127.0.0.1:7001/staff