'use strict';

const Service = require('egg').Service;

class DetailsService extends Service {
   
}

module.exports = DetailsService;
