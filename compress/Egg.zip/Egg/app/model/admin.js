module.exports = app => {
    const {
        STRING,CHAR
    } = app.Sequelize;

    const Admin = app.model.define('admin',{
        username:STRING(11),
        password:CHAR(6),
    })
    return Admin;
}