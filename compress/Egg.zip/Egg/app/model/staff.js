module.exports = app => {
    const {
        STRING
    }   =app.Sequelize;

    const Staff = app.model.define('staff',{
        staff_name:STRING,
        staff_school:STRING,
        staff_phone:STRING,
        staff_categorys:STRING,
    })
    return Staff
}