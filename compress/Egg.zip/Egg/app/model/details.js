module.exports = app => {
    const {
        STRING
    }   =app.Sequelize;

    const Details = app.model.define('details',{
        details_name:STRING,
        details_phone:STRING,
        details_username:STRING,
        details_password:STRING,
    })
    return Details
}