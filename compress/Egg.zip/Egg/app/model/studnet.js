module.exports = app => {
    const {
        STRING
    } = app.Sequelize;
    const Student = app.model.define('student', {
        student_name: STRING,
        student_school: STRING,
        student_phone: STRING,
        student_categorys: STRING,
        parent_name: STRING,
        parent_phone: STRING,
    })
    return Student
}