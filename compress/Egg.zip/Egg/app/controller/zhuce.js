'use strict';

const Controller = require('egg').Controller;

class ZhuceController extends Controller {
    async insertadmin() {
        const insertadmin = await this.ctx.service.admin.insertadmin()
        this.ctx.body = insertadmin
    }

    async zhuce() {
        await this.ctx.render('zhuce.html')
    }

    async create() {
        // const md5=require('md5-node');
        const body = this.ctx.request.body;

        const admin = {
            username: body.username,
            // password:md5(body.password),
            password: body.password
        }
        await this.app.model.Admin.create(admin);
        this.ctx.redirect("/")
    }
}

module.exports = ZhuceController;
