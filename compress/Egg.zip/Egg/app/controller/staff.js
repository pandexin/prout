'use strict'; 
const Controller = require('egg').Controller;

class StaffController extends Controller {
    async get() {
        const stafflist = await this.ctx.service.staff.getstafflist();
        this.ctx.body = stafflist
    }
    async post() {
        const stafflist = await this.ctx.service.staff.insertstafflist();
        this.ctx.body = stafflist
    }
    async destroy() {
        const stafflist = await this.ctx.service.staff.deletestafflist();
        this.ctx.body = stafflist
    }
    async put() {
        const stafflist = await this.ctx.service.staff.putstafflist();
        this.ctx.body = stafflist
    }  
}

module.exports = StaffController;
