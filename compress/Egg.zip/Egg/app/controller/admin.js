'use strict';

const Controller = require('egg').Controller;

class AdminController extends Controller {
    async get() {
        const adminlist = await this.ctx.service.admin.insertadminlist();
        this.ctx.body = adminlist
    }

}

module.exports = AdminController;

