'use strict';

const Controller = require('egg').Controller;

class StudentController extends Controller {
    async getdetails() {
        const details = await this.ctx.service.student.getdetails();
        this.ctx.body = details
    }
    async postdetails() {
        const details = await this.ctx.service.student.postdetails();
        this.ctx.body = details
    }
    async destroydetails() {
        const details = await this.ctx.service.student.destroydetails();
        this.ctx.body = details
    }
    async putdetails() {
        const details = await this.ctx.service.student.putdetails();
        this.ctx.body = details
    }


    async get() {
        const studentlist = await this.ctx.service.student.getstudentlist();
        this.ctx.body = studentlist
    }
    async post() {
        const studentlist = await this.ctx.service.student.poststudent();
        this.ctx.body = studentlist
    }
    async destroy() {
        const studentlist = await this.ctx.service.student.deletestudent();
        this.ctx.body = studentlist
    }
    async put() {
        const studentlist = await this.ctx.service.student.putstudent();
        this.ctx.body = studentlist
    }  
}
module.exports = StudentController;
