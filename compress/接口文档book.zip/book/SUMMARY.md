# Summary

* [介绍](README.md)

## 招生管理系统
* 管理员
    * [员工管理](管理员/employeemanagement.md)
    * [学员信息管理](管理员/Student-Information-Management.md)

-----
<!-- * 学员
    * [新增](学员/newlyadded.md) -->

-----
<!-- * 员工
    * [学员信息](员工/Student-Information.md) -->

-----
* 招生管理系统
    * [登录](招生管理系统/Sign-in.md)
    <!-- * [招生信息](招生管理系统/Enrollment-information.md) -->
    <!-- * [显示页](招生管理系统/Display-Page.md) -->
    <!-- * [用户管理](招生管理系统/user-management.md) -->

-----
* 后完善内容
    * 待定

